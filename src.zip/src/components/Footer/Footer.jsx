import React from 'react';
import { NavLink } from 'react-router-dom';

export const Footer = () => {
  return (
    <footer className="flex justify-between bg-gray-900 text-white p-5 flex-wrap fixed bottom-0 left-0 right-0 w-screen z-50">
      <div className="flex-1 p-2 min-w-[250px] md:min-w-[300px]">
        <h3 className="text-lg mb-2">General Links</h3>
        <ul className="list-none p-0">
          <li className="mb-1">
            <NavLink to="/" className="text-white no-underline hover:underline">
              Home
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/tour-themes" className="text-white no-underline hover:underline">
              Tour By Themes
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/travel-services" className="text-white no-underline hover:underline">
              Travel Services
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/contact" className="text-white no-underline hover:underline">
              Contact Us
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/about" className="text-white no-underline hover:underline">
              About Us
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/tour-destination" className="text-white no-underline hover:underline">
              Tour By Destination
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/testimonials" className="text-white no-underline hover:underline">
              Testimonials
            </NavLink>
          </li>
          <li className="mb-1">
            <NavLink to="/site-map" className="text-white no-underline hover:underline">
              Site Map
            </NavLink>
          </li>
        </ul>
        <select className="mt-2 p-2 bg-gray-800 text-white border-none w-full">
          <option>Select Language</option>
          <option>English</option>
          <option>Spanish</option>
        </select>
      </div>

      <div className="flex-1 p-2 min-w-[250px] md:min-w-[300px]">
        <h3 className="text-lg mb-2">Quick Contact</h3>
        <address className="not-italic">
          <p>Sixth Sense Holidays</p>
          <p>Mr. Nilesh Pawaskar</p>
          <p>Office No 159, Shopper Orbit Mall, Pune, India</p>
          <a href="mailto:info@sixthsenseholidays.com" className="text-white no-underline hover:underline">
            info@sixthsenseholidays.com
          </a>
        </address>
      </div>

      <div className="flex-1 p-2 min-w-[250px] md:min-w-[300px]">
        <h3 className="text-lg mb-2">Quick Enquiry</h3>
        <form className="space-y-2">
          <input type="text" placeholder="Your Name" className="w-full p-2 bg-gray-800 text-white border-none" />
          <input type="email" placeholder="Email" className="w-full p-2 bg-gray-800 text-white border-none" />
          <select className="w-full p-2 bg-gray-800 text-white border-none">
            <option>India</option>
            <option>USA</option>
          </select>
          <input type="tel" placeholder="Phone / Mobile" className="w-full p-2 bg-gray-800 text-white border-none" />
          <textarea 
            placeholder="Leave a Message for us" 
            className="w-full p-2 bg-gray-800 text-white border-none h-24"
          ></textarea>
          <button 
            type="submit" 
            className="bg-orange-500 text-white border-none px-5 py-2 cursor-pointer hover:bg-orange-600"
          >
            Send Message
          </button>
        </form>
      </div>
    </footer>
  );
};
