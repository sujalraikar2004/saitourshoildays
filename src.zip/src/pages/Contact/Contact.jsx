import React from 'react'
import { Layout } from '../layout/Layout'

export const Contact = () => {
  return (
    <Layout> <div>Contact</div></Layout>
   
  )
}
