import React from 'react'
import { Layout } from '../layout/Layout'

export const AirlineTicketing = () => {
  return (
    <Layout>
      <div>Airline Ticketing Services</div>
    </Layout>
  )
}
