import React from 'react'
import { Layout } from '../layout/Layout'

export const TourOperators = () => {
  return (
    <Layout>
      <div>Tour Operators Page</div>
    </Layout>
  )
}
