import React from 'react'
import { Layout } from '../layout/Layout'

export const HotelBooking = () => {
  return (
    <Layout>
      <div>Hotel Booking Services</div>
    </Layout>
  )
}
