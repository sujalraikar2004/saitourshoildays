import React from 'react'
import { Layout } from '../layout/Layout'

export const EventOrganizer = () => {
  return (
    <Layout>
      <div>Event Organization Services</div>
    </Layout>
  )
}
