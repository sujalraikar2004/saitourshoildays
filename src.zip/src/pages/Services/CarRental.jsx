import React from 'react'
import { Layout } from '../layout/Layout'

export const CarRental = () => {
  return (
    <Layout>
      <div>Car Rental Services</div>
    </Layout>
  )
}
