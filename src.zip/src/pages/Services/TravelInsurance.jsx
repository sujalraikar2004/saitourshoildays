import React from 'react'
import { Layout } from '../layout/Layout'

export const TravelInsurance = () => {
  return (
    <Layout>
      <div>Travel Insurance Services</div>
    </Layout>
  )
}
