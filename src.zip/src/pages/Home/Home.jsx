import React from 'react'
import { Layout } from '../layout/Layout'
export const Home = () => {
  return (

<Layout><div> akjedhfdljka Home</div></Layout>
    
  )
}
