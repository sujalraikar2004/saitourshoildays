import React, { useEffect, useRef } from 'react'

export default function About() {
  const sections = useRef([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-8');
          }
        });
      },
      { threshold: 0.1 }
    );

    sections.current.forEach(section => observer.observe(section));
    
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      {/* Hero Section */}
      <div 
        ref={el => sections.current[0] = el}
        className="relative py-20 px-6 bg-indigo-900 text-white opacity-0 translate-y-8 transition-all duration-500"
      >
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Crafting Unforgettable Journeys
          </h1>
          <p className="text-xl text-indigo-100 mb-8">
            Transforming travel dreams into reality since 2010
          </p>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div 
          ref={el => sections.current[1] = el}
          className="prose prose-lg text-gray-600 mb-16 opacity-0 translate-y-8 transition-all duration-500 delay-100"
        >
          <p className="text-xl">
            Travelling is one of the few things in life that provides true happiness. Sai Tours is a premium travel company based in Karwar, Karnataka, renowned for delivering exceptional travel experiences through our comprehensive services.
          </p>
        </div>

        {/* Stats Grid */}
        <div 
          ref={el => sections.current[2] = el}
          className="grid md:grid-cols-2 gap-8 mb-16 opacity-0 translate-y-8 transition-all duration-500 delay-200"
        >
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-indigo-50">
            <h3 className="text-2xl font-bold text-indigo-600 mb-4">Our Leadership</h3>
            <p className="text-gray-600 mb-2">
              <span className="font-semibold">CEO:</span> Mr. Gurudas Revankar
            </p>
            <p className="text-gray-600">
              <span className="font-semibold">Founded:</span> 2010
            </p>
          </div>
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-indigo-50">
            <h3 className="text-2xl font-bold text-indigo-600 mb-4">Our Commitment</h3>
            <p className="text-gray-600">
              Client-centric approach with 100% transparent deals and ethical business practices
            </p>
          </div>
        </div>

        {/* Services Section */}
        <h2 
          ref={el => sections.current[3] = el}
          className="text-3xl font-bold text-gray-800 mb-8 opacity-0 translate-y-8 transition-all duration-500 delay-300"
        >
          Our Services
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {[
            {
              title: 'Airline Ticketing',
              icon: '✈️',
              desc: 'Expert booking services for domestic & international flights with best fares'
            },
            {
              title: 'Hotel Booking',
              icon: '🏨',
              desc: 'Curated selection of premium accommodations to match your preferences'
            },
            {
              title: 'Car Rental',
              icon: '🚗',
              desc: 'Luxury and economy vehicles with chauffeur options available'
            },
            {
              title: 'Travel Insurance',
              icon: '🛡️',
              desc: 'Comprehensive coverage plans for worry-free travels'
            },
            {
              title: 'Tour Packages',
              icon: '🌴',
              desc: 'Customized domestic, international, adventure & beach island tours'
            },
            {
              title: 'MICE Services',
              icon: '🤝',
              desc: 'End-to-end corporate event management & group travel solutions'
            }
          ].map((service, index) => (
            <div
              key={index}
              className="group bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 border border-transparent hover:border-indigo-100"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold text-indigo-600 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {service.desc}
              </p>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center py-12">
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-300 transform hover:scale-105">
            Start Your Journey
          </button>
        </div>
      </div>
    </div>
  );
}
