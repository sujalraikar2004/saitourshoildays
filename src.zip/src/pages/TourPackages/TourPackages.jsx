import React from 'react'
import { Layout } from '../layout/Layout'

export const TourPackages = () => {
  return (
    <Layout>
      <div>Tour Packages Page</div>
    </Layout>
  )
}
